import libhelloworld

def add_1(a,b):
  return a+b

def add(a,b):
  return libhelloworld.add(a,b)

def  sayhello():
  libhelloworld.sayHello()

  

 

