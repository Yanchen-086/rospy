

from rospy import libhelloworldpy

print(libhelloworldpy.add_1(1,2))
print(libhelloworldpy.add(1,2))
libhelloworldpy.sayhello()
print(libhelloworldpy.sayhello())
